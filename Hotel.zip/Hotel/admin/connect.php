<?php
	$conn = new mysqli("localhost", "root", "", "Hotel") or die(mysqli_error());
