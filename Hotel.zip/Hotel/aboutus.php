<!DOCTYPE html>
<html lang = "en">
	<head>
		<title>Hotel Online Reservation</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css " />
		<link rel = "stylesheet" type = "text/css" href = "css/style.css" />
	</head>
<body>
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div  class = "container-fluid">
			<div class = "navbar-header">
				<a class = "navbar-brand" >Hotel Online Reservation</a>
			</div>
		</div>
	</nav>	
	<ul id = "menu">
		<li><a href = "index.php">Home</a></li> |
		<li><a href = "aboutus.php">About us</a></li> |
		<li><a href = "contactus.php">Contact us</a></li> |
		<li><a href = "gallery.php">Gallery</a></li> |
		<li><a href = "dineandlounge.php">Dine and Lounge</a></li> |			
		<li><a href = "reservation.php">Make a reservation</a></li> |
		<li><a href = "rulesandregulation.php">Rules and Regulation</a></li>
	</ul>
	<div style = "margin-left:0;" class = "container">
		<div class = "panel panel-default">
			<div class = "panel-body">
				<strong><h3>ABOUT US</h3></strong>
				<p style = "position:relative; float:left; width:850px;">Hotel unveils a celebrated balance of nostalgia and contemporary style, capturing its original Southern elegance, luxury, and decadence. Machuca tiles form cool geometric patterns in the hallways. Hotel hardwood floors contrast modern furnishings and amenities in the dramatic suites.
					The Hotel lifestyle offers guests the finest sensory indulgences: soothing organic toiletries, heirloom recipes, and unmatched privacy and tranquility</p>
				<img style = "float:right;" src = "images/about.jpg" width = "250px" height = "250px" />
				<br style = "clear:both;" />
				<br />
				<br />
				<hr style = "border:1px dotted #000;" />
				<br />
				<div style = "float:left; margin-left:40px; width:300px; height:300px; ">
					<center><img src = "images/1.jpg" width = "250px" height = "250px"  style = "margin-top:5px;"/></center>
					<center><h4 style = "color:rgba(0, 255, 0, 1);">Standard</h4></center>
					<center><label>Small Size Bed</label> <label style = "color:red;"> 2,000</label></center>
				</div>
				
				<div style = "float:left; margin-left:40px; width:300px; height:300px; ">
					<center><img src = "images/3.jpg" width = "250px" height = "250px"  style = "margin-top:5px;"/></center>
					<center><h4 style = "color:rgba(0, 255, 0, 1);">Superior</h4></center>
					<center><label>1 Medium Size Bed</label> <label style = "color:red;">2,400 </label></center>
				</div>
			
				<br />
				<div style = "float:left; margin-left:40px; width:300px; height:300px; ">
					<center><img src = "images/4.jpg" width = "250px" height = "250px"  style = "margin-top:5px;"/></center>
					<center><h4 style = "color:rgba(0, 255, 0, 1);">Super Deluxe</h4></center>
					<center><label>2 Medium Size Bed</label> <label style = "color:red;"> 2,800 </label></center>
				</div>
					<br style = "clear:both;"/>
				<div style = "float:left; margin-left:40px; width:300px; height:300px; ">
					<center><img src = "images/5.jpg" width = "250px" height = "250px"  style = "margin-top:5px;"/></center>
					<center><h4 style = "color:rgba(0, 255, 0, 1);">Jr. Suite</h4></center>
					<center><label>Matrimonial</label> <label style = "color:red;"> 3,800 </label></center>
				</div>
				<div style = "float:left; margin-left:40px; width:300px; height:300px; ">
					<center><img src = "images/6.jpg" width = "250px" height = "250px"  style = "margin-top:5px;"/></center>
					<center><h4 style = "color:rgba(0, 255, 0, 1);">Executive Suite</h4></center>
					<center><label>Matrimonial</label> <label style = "color:red;"> 4,000 </label></center>
				</div>
				<br style = "clear:both;"/>
				<br />
				<br />
				<strong><h3>Amenities and Services</h3></strong>
				<ul>
					<li><label>24 Hour room service</label></li>
					<li><label>21" Flat screen TV with cable service</label></li>
					<li><label>Hot & cold shower</label></li>
					<li><label>Refrigerator and mini bar on demand in all suites and superior rooms</label></li>
					<li><label>Coffee & tea set, bottled water, organic tolletries in suites and superior rooms</label></li>
					<li><label>Hair dryer in suite rooms</label></li>
					<li><label>Personal safety boxes in every room</label></li>
					<li><label>Laundry & pressing</label></li>
					<li><label>Free use Wifi</label></li>
					<li><label>In room massage services</label></li>
					<li><label>Personal Safe in Every Room</label></li>
					<li><label>Mini Bar</label></li>
					<li><label>7 Function & Meeting Rooms</label></li>
					<li><label>Road Trip Airport Transfers & Special City Tour</label></li>
					<li><label>Swimming Pool</label></li>
					<li><label>Gift Shop</label></li>
					<li><label>Business Center</label></li>
					<li><label>Free Parking for Guest</label></li>
				</ul>
			</div>
		</div>
	</div>
	<br />
	<br />
	
</body>
<script src = "js/jquery.js"></script>
<script src = "js/bootstrap.js"></script>	
</html>